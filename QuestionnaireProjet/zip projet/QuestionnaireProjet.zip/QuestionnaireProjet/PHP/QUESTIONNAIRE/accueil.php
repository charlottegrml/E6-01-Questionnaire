<?php 
session_start();
include '../BDD/cnx.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); 
    exit;
}


//recupere l'id
$user_id = $_SESSION['user_id'];
$stmt = $cnx->prepare("SELECT NomUtilisateur, Nom, Prenom, Role, email FROM utilisateurs WHERE id = :user_id");
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../CSS/style2.css">
</head>
<body>
    <div id="bienvenue"><h2 id="txtbienvenue"> Bienvenue <?php echo $user['Prenom']; ?> ! </h2></div>
    <div id="deconnecteypnl"> <a  href="../PROFIL/modifierProfile.php" class="btn btn-primary">Modifier mon profil</a>
     <a  href="../LOGIN/login.php" class="btn btn-primary">Déconnexion</a></div>
       <div id="lstquestionnaire"><h1> Liste des Questionnaires : </h1></div> 
        <table class="table table-striped">
            <thead>
                <div id="table">
                <tr>
                    <th>Nom</th>
                    <th>Thème</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $sql = $cnx->prepare("SELECT q.Id, q.Libelle, t.Nom AS ThemeNom FROM questionnaire q INNER JOIN theme t ON q.ThemeId = t.Id");
                    $sql->execute();
                    foreach($sql->fetchAll(PDO::FETCH_ASSOC) as $row) {
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['Libelle']); ?></td>
                    <td><?php echo htmlspecialchars($row['ThemeNom']); ?></td>
                    <td>
                        <a href="question.php?id=<?php echo $row['Id']; ?>" class="btn btn-primary">Commencer</a>
                    </td>
                </tr>
                </div>
                <?php
                    }
                ?>
            </tbody>
        </table>
    
</body>
</html>
